package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-06-12 21:59
 */
@Data
public class SimpleRepoVo {
    Long id;
    String gitUrl;
}
