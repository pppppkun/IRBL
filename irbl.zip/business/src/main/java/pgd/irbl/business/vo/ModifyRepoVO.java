package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-03-24 21:22
 */
@Data
public class ModifyRepoVO {
    Long repoId;
    String description;
}
