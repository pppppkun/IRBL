package pgd.irbl.business.vo;

/**
 * @Author: pkun
 * @CreateTime: 2021-03-25 22:46
 */
public class WebhookBody {
}
