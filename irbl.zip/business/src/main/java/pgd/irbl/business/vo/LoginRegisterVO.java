package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-03-29 13:44
 */
@Data
public class LoginRegisterVO {

    String username;
    String password;

}
