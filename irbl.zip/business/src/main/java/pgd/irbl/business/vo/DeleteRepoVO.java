package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-03-24 21:21
 */
@Data
public class DeleteRepoVO {
    Long repoId;
}
