package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-06-14 15:54
 */
@Data
public class FilePath {
    String path;
}
