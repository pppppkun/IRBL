package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-04-05 22:43
 */
@Data
public class QueryRecordVO {

    String recordId;

}
