package pgd.irbl.business.dao;

import org.apache.ibatis.annotations.Mapper;

/**
 * ComPreMapper = Commit Preprocess Mapper
 * @Author: pkun
 * @CreateTime: 2021-03-25 23:15
 */
@Mapper
public interface ComPreMapper {
}
