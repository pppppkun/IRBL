package pgd.irbl.business.vo;

import lombok.Data;

/**
 * @Author: pkun
 * @CreateTime: 2021-06-09 10:40
 */
@Data
public class WebhookVO {

    String commitId;
    String gitUrl;

}
