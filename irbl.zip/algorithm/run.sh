nohup python calculator_server.py > calculator_server.log 2>&1 &
python preprocessor_server.py > preprocessor_server.log 2>&1
