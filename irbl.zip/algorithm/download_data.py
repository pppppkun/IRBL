import nltk

def download():
    nltk.download('punkt')


if __name__ == "__main__":
    download()
    nltk.download('averaged_perceptron_tagger')
